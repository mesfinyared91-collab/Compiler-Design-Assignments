# Principles of Compiler Design – Assignment 01

## Student Information
- **Name:** Yared Mesfin  
- **ID:** 1411368  
- **Department:** CS  
- **University:** Bahir Dar University  

---

## Question 1 (Theory): Predictive Parsing

### Definition
Predictive parsing is a **top-down parsing technique** used in syntax analysis of compilers.  
It parses the input from **left to right** and constructs a **leftmost derivation** **without using backtracking**.

The parser predicts which grammar rule to apply by examining:
- The **current non-terminal symbol**  
- The **next input symbol (lookahead)**

### How Predictive Parsing Works
1. Start with the **start symbol**.  
2. Read the **next input symbol** (lookahead).  
3. Use a **parsing table** (built from **FIRST** and **FOLLOW** sets) to select the production.  
4. Repeat until the input string is **accepted** or **rejected**.

### LL(1) Grammars
Predictive parsing works best with **LL(1) grammars**, where:

- **L** → Scan input from **Left to right**  
- **L** → Produce **Leftmost derivation**  
- **(1)** → Use **one lookahead symbol**

### Key Characteristics
- **No backtracking** → efficient and fast  
- **Time complexity:** O(n)  
- **Simple to implement**

### Grammar Requirements
- **No left recursion**  
- Must be **left factored**  
- **Unambiguous grammar**

---

## Next Questions
- [Question 2 – Count Identifiers](Question2/README.md)  
- [Question 3 – Parse Tree](Question3/README.md)
